## Python and Environment Setup Recommendations



Please see the [README.md](../../setup/README.md) in the [setup](../../setup) directory for Python installation and setup recommendations.



