# Appendix C: Exercise Solutions



- [Chapter 2 exercise solutions](../ch02/01_main-chapter-code/exercise-solutions.ipynb)
- [Chapter 3 exercise solutions](../ch03/01_main-chapter-code/exercise-solutions.ipynb)
- [Chapter 4 exercise solutions](../ch04/01_main-chapter-code/exercise-solutions.ipynb)
- [Chapter 5 exercise solutions](../ch05/01_main-chapter-code/exercise-solutions.ipynb)
- [Chapter 6 exercise solutions](../ch06/01_main-chapter-code/exercise-solutions.ipynb)
- [Chapter 7 exercise solutions](../ch07/01_main-chapter-code/exercise-solutions.ipynb)